-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: fulfillment-service
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fulfillments`
--

DROP TABLE IF EXISTS `fulfillments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fulfillments` (
  `id` binary(16) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `customer_id` binary(16) NOT NULL,
  `fulfillment_type` varchar(30) NOT NULL,
  `order_id` binary(16) NOT NULL,
  `shipping_address_id` binary(16) NOT NULL,
  `status` varchar(30) NOT NULL,
  `store_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_rksk0lb23na52f941uubcuea2` (`order_id`),
  CONSTRAINT `fulfillments_chk_1` CHECK ((`fulfillment_type` in (_utf8mb4'SHIP_TO_HOME',_utf8mb4'STORE_PICKUP',_utf8mb4'DIGITAL'))),
  CONSTRAINT `fulfillments_chk_2` CHECK ((`status` in (_utf8mb4'PENDING',_utf8mb4'ALLOCATED',_utf8mb4'PACKING',_utf8mb4'READY_TO_SHIP',_utf8mb4'SHIPPED',_utf8mb4'DELIVERED',_utf8mb4'CANCELLED',_utf8mb4'FAILED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fulfillments`
--

LOCK TABLES `fulfillments` WRITE;
/*!40000 ALTER TABLE `fulfillments` DISABLE KEYS */;
INSERT INTO `fulfillments` VALUES (_binary 'ל��G-�\�!߯*�K','2026-09-11 08:33:07.599845','2026-09-11 09:10:28.911435',_binary '�\�;d:A���}ʑ.�','SHIP_TO_HOME',_binary '\��\�\"N�����+a',_binary '\�\�\Z{I�M���,\�dc�','SHIPPED','store-gachibowli'),(_binary 'W�ɂJl�T���|�\�','2026-09-11 07:27:14.686488','2026-09-11 07:28:35.908301',_binary '�\�;d:A���}ʑ.�','SHIP_TO_HOME',_binary 'aܱj��Db�������7',_binary 'i�\��#�H�f\�庄\��','DELIVERED','india-store-1-3'),(_binary 'jf\�et\rEg�qh��ѫ�','2026-09-15 05:08:01.844677','2026-09-15 05:09:36.725843',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary '�6\�!\�E\n�\�X\"E��~',_binary '�8�֋H��j\�¾�\�Y','DELIVERED','india-store-1-1'),(_binary 'zv)���FܓMI0h�/b','2026-09-15 05:06:24.066687','2026-09-15 05:06:53.835603',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary 'В۫�\�N��\rʷr5',_binary '\�I@P�ĩ+�$|\�','DELIVERED','india-store-1-1'),(_binary '�\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2026-09-11 12:27:57.214600','2026-09-11 12:27:57.214600',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary 'p\0\0\0\0\0\0\0\0\0\0\0\0\0\0',_binary 'c\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIPPED','store-gachibowli'),(_binary '�h���Bs��\�&k\��','2026-09-11 06:58:25.650615','2026-09-11 07:04:53.292139',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary '?��]�I�tȝ�?�$',_binary '��2[\�O��\�\�ZN�','DELIVERED','india-store-1-1'),(_binary '��\���\�Kء�\�\�A�	','2026-09-11 07:21:36.381654','2026-09-11 07:26:29.130009',_binary '�\�;d:A���}ʑ.�','SHIP_TO_HOME',_binary '1�C�\�-FW����c.',_binary 'vf\�vNߍ`���\�Ȟ','DELIVERED','india-store-1-1'),(_binary '�3S`D	��v\n3b�]','2026-09-22 10:02:57.598532','2026-09-22 10:09:55.426204',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary '\�ͤ,�\�MG��@P���',_binary '/���r{G+�`�;\��C�','DELIVERED','india-store-1-3'),(_binary 'ԴHw@�o:\��r\�','2026-09-15 05:34:09.282631','2026-09-15 05:36:19.522718',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary '2\�\�CGԳ�\�-�q\�',_binary ',���):Bb�����\�\�','DELIVERED','india-store-1-1'),(_binary '\�\�O\�!ME��)�0�vX\�','2026-09-21 11:41:26.009150','2026-09-21 11:43:30.218992',_binary '`\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SHIP_TO_HOME',_binary '5Dc\�=J��R\�jbi��',_binary '����GG�\�\�[wq\�','DELIVERED','india-store-1-1'),(_binary '\�\�7�L�\���.��','2026-09-11 07:59:57.024870','2026-09-11 08:00:06.835190',_binary '�\�;d:A���}ʑ.�','SHIP_TO_HOME',_binary 'k�U�hMW�Hi\�.�= ',_binary '[Q\�KLF�\�q�w�D�','SHIPPED','india-store-1-1');
/*!40000 ALTER TABLE `fulfillments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-22  8:33:10
